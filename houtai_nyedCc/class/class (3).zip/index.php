<?php 
header("location:http://baidu.com");
?>